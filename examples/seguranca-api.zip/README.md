# Sessão e JWT com Spring Security

Exemplo didático do blog Vark. Java 21 e Maven 3.9. Spring Boot 3.5.16.

`mvn test` roda os testes com chaves RSA geradas em memória. Nenhum provedor externo é chamado.

Para iniciar, defina `DEMO_PASSWORD` com uma senha local e execute `mvn spring-boot:run`.
Abra http://127.0.0.1:8080/web/conta e autentique com o usuário `neto` e a senha definida.
O usuário é mantido em memória apenas para demonstrar sessão. Não é um cadastro de produção.

Para usar `/api/conta`, configure `JWT_ISSUER`, `JWT_JWKS` e `JWT_AUDIENCE` para um provedor de identidade seu.
Envie um access token RS256 válido, destinado à audience configurada, com scope `conta:ler`.
Os endereços example.invalid são placeholders. Este projeto não emite tokens nem implementa refresh.

O serviço escuta apenas em localhost. A implantação exige HTTPS, `SESSION_COOKIE_SECURE=true`,
armazenamento de usuários e política de expiração/revogação definida para o produto.
Cookies e cabeçalhos HTTP de um servidor real precisam ser verificados fora do MockMvc.
